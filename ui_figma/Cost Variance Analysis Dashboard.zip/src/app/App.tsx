import { useState } from 'react';
import { MainDashboard } from './components/MainDashboard';

export default function App() {
  return <MainDashboard />;
}
