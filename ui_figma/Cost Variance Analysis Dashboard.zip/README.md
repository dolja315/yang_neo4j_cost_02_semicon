
  # Cost Variance Analysis Dashboard

  This is a code bundle for Cost Variance Analysis Dashboard. The original project is available at https://www.figma.com/design/dHdYIjX9D9CIhnAq5ifAIS/Cost-Variance-Analysis-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  